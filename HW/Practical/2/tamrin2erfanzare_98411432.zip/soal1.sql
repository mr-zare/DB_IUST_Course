create table company1(
role nvarchar(20) not null,
Nationalcode nvarchar(10) not null,
Last_Name nvarchar(50) not null,
First_Name nvarchar(50) not null,
id int not null primary key,
parentid int not null,foreign key(parentid) references company1(id)
);

drop table company




/*3
create function idcheck(id1 int)
return nvarchar(50)
declare id;
begin
if((select role from company where id=id1)='co')
{
select * from company where role in{'',''};
}
if((select role from company where id=id1)='co')
{
select * from company where role in{'',''};
}
if((select role from company where id=id1)='co')
{
select * from company where role in{'',''};
}
end;
*/
declare @id int;
with cte as (select c.* from company1 c where c.id=@id union all
select c.* from company1 c inner join cte ct on c.parentid=ct.id)
select * from cte;

/*4*/
go
create procedure swaping2p @id_1 int , @id_2 int
as
begin
    declare @role_p  nvarchar(20);
    declare @id_p    int;
    set @id_p = (select parentid from company1 where company1.id = @id_1);
    set @role_p = (select role from company1 where company1.id = @id_1);


    update company1
    set role = (select [ROLE] from company1 where company1.id = @id_2),
	parentid = (select parentid from company1 where company1.id = @id_2)
    where company1.id = @id_1;

    update company1
    set role = @role_p,parentid = @id_p
    where company1.id = @id_2;
    
    declare @tmplist table (id int);
    insert into @tmplist
    select id
    from company1
    where company1.parentid = @id_2;

    update company1
    set parentid = @id_2
    where company1.parentid = @id_1;
      
    update company1
    set parentid = @id_1
    where company1.id in (select id from @tmplist);
END;
EXEC Swaping2p 1,4;
select *
from company1;

/*5*/
go
create procedure delwith2id 
   @id_1 int, @id_2 int 
AS
BEGIN
    UPDATE company1
    SET parentid = @id_2
    WHERE parentid = @id_1
    DELETE FROM company1 WHERE id = @id_1
END;

EXEC delwith2id 3,2;

/*6*/
go
create procedure insertitobranch @role nvarchar(20),@nidd nvarchar(10),@last_name nvarchar(50),@first_name nvarchar(50), @idd int , @parentidd int
as begin
    insert into company1
    values (@role,@nidd,@last_name,@first_name,@idd,@parentidd)
end;
exec insertitobranch @role='E' ,@nidd='0123456789' ,@last_Name='erfan' ,@first_name='zare' ,@idd=9,@parentidd=2;

select * from company1

/*-----------------------------------------------------------------------------------------------*/
insert into company (role,Nationalcode,Last_Name,First_Name,id,parentid) values('CEO',1234567890,'Jafari','Ali',1,0);
insert into company (role,Nationalcode,Last_Name,First_Name,id,parentid) values('HRM',1236547524,'Kazemi','Zahra',2,1);
insert into company (role,Nationalcode,Last_Name,First_Name,id,parentid) values('FM',1236523654,'Akbari','Saleh',3,1);
insert into company (role,Nationalcode,Last_Name,First_Name,id,parentid) values('TM',1246578125,'Bageri','Reza',4,1);
insert into company (role,Nationalcode,Last_Name,First_Name,id,parentid) values('E',4512547856,'Ahmadi','Sina',5,3);
insert into company (role,Nationalcode,Last_Name,First_Name,id,parentid) values('E',2365478941,'Zare','Melika',6,4);
insert into company (role,Nationalcode,Last_Name,First_Name,id,parentid) values('E',1230212015,'Askari','Maryam',7,4);
insert into company (role,Nationalcode,Last_Name,First_Name,id,parentid) values('E',1203201458,'Moradi','Mehrdad',8,4);

select * from company
