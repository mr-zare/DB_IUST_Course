create table class(classid int primary key,c_name nvarchar(30) not null,caption text
,status1 varchar(2) not null,date_start date not null,date_end date not null,level_class nvarchar(8) not null,teacher nvarchar(50) not null,topic nvarchar(1) not null,
constraint check_date check(date_end >date_start), constraint check_status check (status1 in ('A','NA','AR')),
constraint check_level check (level_class in(1,2,3,4,5,6,7,8,9,10,11,12,'1','2','3','4','5','6','7','8','9','10','11','12',
'1st','2nd','3rd','4th','5th','6th','7th','8th','9th','10th','11th','12th')),constraint catg check(topic in('M','P','C','B','F','E','A','R'))
);


insert into class values(1,'helli1','darsrizi','A','2014-02-01','2014-07-02',1,'nima','M');
insert into class values(2,'helli2','darsfizik','NA','2015-02-01','2015-07-02',2,'ali','P');
insert into class values(3,'helli3','shimi','A','2016-02-01','2016-07-02',3,'reza','C');
insert into class values(4,'helli4','arabi','AR','2017-02-01','2017-07-02',4,'erfan','A');
insert into class values(5,'helli5','zist','NA','2018-02-01','2018-07-02',5,'amin','B');
insert into class values(6,'helli6','zaban','AR','2019-02-01','2019-07-02',6,'sam','E');


insert into student values(98400000,'aa','11','amir','amiri','aa@gmail.com',1,'2004-02-02','0011111111','tehran',11111111);
insert into student values(98400002,'bb','22','bmir','bmiri','bb@gmail.com',2,'2005-02-02','0021111111','tehran',21111111);
insert into student values(98400003,'cc','33','cmir','cmiri','cc@gmail.com',3,'2006-02-02','0031111111','kerman',31111111);
insert into student values(98400004,'dd','44','dmir','dmiri','dd@gmail.com',4,'2007-02-02','0041111111','yazd',41111111);
insert into student values(98400005,'ee','55','emir','emiri','ee@gmail.com',5,'2008-02-02','0051111111','shiraz',51111111);
insert into student values(98400006,'ff','66','fmir','fmiri','ff@gmail.com',6,'2009-02-02','0061111111','esfehan',61111111);



create table student(student_id int primary key not null,s_name nvarchar(30) not null ,pass nvarchar(20) not null,first_name nvarchar(20)not null
,last_name nvarchar(20) not null,email nvarchar(30) ,class_id int not null references class(classid) ON DELETE NO ACTION,
birth_date date not null,s_id nvarchar(10) not null,constraint chk_sid check (s_id like '[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]')
,s_address nvarchar(70) not null,phone int not null check(phone between 10000000 and 100000000));

select * from student;




insert into Schedule values(1,1,1,3,'2014-01-01','2014-07-01');
insert into Schedule values(2,2,2,4,'2014-02-02','2014-07-02');
insert into Schedule values(3,3,3,5,'2014-03-03','2014-07-03');
insert into Schedule values(4,4,5,7,'2014-04-04','2014-07-04');
insert into Schedule values(5,5,1,3,'2014-05-05','2014-07-05');
insert into Schedule values(6,6,2,4,'2014-06-06','2014-07-06');

create table Schedule (week_id int primary key not null,class_id int references class(classid) ON DELETE CASCADE
,day1 int,constraint day_week1 check(day1 in(1,2,3,4,5,6,7)),day2 int,constraint day_week2 check(day2 in(1,2,3,4,5,6,7)),
date_start date not null,date_end date not null,constraint check_date1 check(date_end >date_start));

insert into homework values(1,'b1','badbakhti1','c/darsi/1',1,'2014-03-01','2014-03-11');
insert into homework values(2,'b2','badbakhti2','c/darsi/2',2,'2014-03-02','2014-03-12');
insert into homework values(3,'b3','badbakhti3','c/darsi/3',3,'2014-03-03','2014-03-13');
insert into homework values(4,'b4','badbakhti4','c/darsi/4',4,'2014-03-04','2014-03-14');
insert into homework values(5,'b5','badbakhti5','c/darsi/5',5,'2014-03-05','2014-03-15');
insert into homework values(6,'b6','badbakhti6','c/darsi/6',6,'2014-03-06','2014-03-16');

create table homework(homework_id int primary key not null,title nvarchar(20) not null,caption text ,fileadrs nvarchar(100) not null,class_id int REFERENCES [Class] ([classid]) ON DELETE CASCADE,
realsehomework date,deadline date,constraint timecheck check(deadline>realsehomework ));

insert into answer_hw values(1,'javab1','c/d/javab/1',1,98400000,'M','2014-03-11','2014-03-21');
insert into answer_hw values(2,'javab2','c/d/javab/2',2,98400002,'P','2014-03-12','2014-03-22');
insert into answer_hw values(3,'javab3','c/d/javab/3',3,98400003,'C','2014-03-13','2014-03-23');
insert into answer_hw values(4,'javab4','c/d/javab/4',4,98400004,'A','2014-03-14','2014-03-24');
insert into answer_hw values(5,'javab5','c/d/javab/5',5,98400005,'B','2014-03-15','2014-03-25');
insert into answer_hw values(6,'javab6','c/d/javab/6',6,98400006,'E','2014-03-16','2014-03-26');

create table answer_hw(answerid int primary key not null,caption nvarchar(100) null,fileaddr nvarchar(100) not null,
hwid int not null references homework(homework_id) ON DELETE CASCADE,studentid int not null references student(student_id) ON DELETE CASCADE,
category nvarchar(1) not null,constraint catg2 check(category in('M','P','C','B','F','E','A','R')),releasedate date,tahvildate date,CONSTRAINT uniquehw_student UNIQUE(hwid, studentid),
constraint check2 check(releasedate<tahvildate));

insert into scoreanshw values(1,1,1,20);
insert into scoreanshw values(2,2,2,19);
insert into scoreanshw values(3,3,3,18);
insert into scoreanshw values(4,4,4,17);
insert into scoreanshw values(5,5,5,16);
insert into scoreanshw values(6,6,6,15);

GO
create table scoreanshw(scoreid int primary key not null,homeworkid  int not null references homework(homework_id) ON DELETE NO ACTION , anshw int  references answer_hw(answerid) on DELETE CASCADE,
score int null constraint nmore check(score>=1 and score<=20),CONSTRAINT uniquescore UNIQUE (homeworkid, anshw));
GO
CREATE TRIGGER insertnomre
ON answer_hw
AFTER INSERT
AS
BEGIN
    SET NOCOUNT ON;
 
       DECLARE @howo_id int,@howoa_id int
       SELECT @howo_id = inserted.hwid, @howoa_id = INSERTED.answerid       
       FROM INSERTED
       INSERT into scoreanshw(homeworkid,anshw,score) VALUES (@howo_id, @howoa_id, null)
END 
GO

--query
GO
create procedure tclasscount as select count(distinct classid) as tedad from class;

GO
create procedure tclasswithgrade as select level_class,count(distinct classid) from class group by level_class;

GO
create procedure tstudentcount as select count(distinct student_id) from student;

GO
create procedure findnomre @clas_id int,@homwoid int as select min(shw.score)mini,max(shw.score) maxi,avg(shw.score) average,var(shw.score) variance  from class c join homework hw on c.classid=hw.class_id join scoreanshw shw on shw.homeworkid=hw.homework_id
where c.classid=@clas_id and hw.homework_id=@homwoid;

GO
create procedure findnomehw @howo_id int as select anhw.studentid,sahw.score from answer_hw anhw join scoreanshw sahw on anhw.hwid=sahw.homeworkid
where anhw.hwid=@howo_id;

GO
create procedure wekklyscheduleforst @clas_id int as select st.student_id,c.topic,s.day1,S.day2,s.date_start,s.date_end from Schedule s join class c on s.class_id=c.classid join student st on s.class_id=st.class_id where c.classid=@clas_id 
order by s.day1,s.day2,s.date_start;


