﻿use [final bank refah]
select * from dbo.final
--1 
select * from dbo.final where CAST(Cars_Count as int) < (select AVG(CAST(Cars_Count as float)) from dbo.final)
--2
-- ba farz in ke faqat sotoon sood ha mad nazar faqat boode ast
--yani dar modat har sal soodash bishtar shode
select Id,Gender from dbo.final where (Sood96-Sood95)>0 and (Sood97-Sood96)>0
select count(*) from dbo.final where (Sood97-Sood95)>0

--3
select SenfName from dbo.final where SenfName like N'%ن%'

--4
-- in soal ro sen afraad ro barhasb sal mohasebe kardam.
select Daramad_Total_Rials,Id from dbo.final where DATEDIFF(YY,BirthDate,GETDATE())=50 and CountyName=N'تهران' order by Daramad_Total_Rials desc

--5
select id,Bardasht97 from dbo.final where Gender=N'مرد' and Bardasht97>30000000 order by Bardasht97 desc
