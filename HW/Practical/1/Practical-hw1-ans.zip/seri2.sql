use pubs
--1
select a.title,a.type from titles AS a where price>17 and price<21 and type!='mod_cook'
--2
select au_id,phone,CONCAT(au_fname,' ',au_lname) AS Full_Name from authors where city='Oakland'
--3 
--ba farz mohasebe sabeqe kari be maah
select top 1 *,DATEDIFF(yy,hire_date,GETDATE()) AS work_experience  from employee order by hire_date 
--4
select * from titles where DATEDIFF(YY,pubdate,GETDATE())>30
--5 
select concat(A.au_fname,' ',A.au_lname) As Full_Name, A.address, SUM(c.qty) as tedad_ketab from authors as A
inner join dbo.titleauthor as b on A.au_id = b.au_id inner join dbo.sales as c on b.title_id = c.title_id
group by A.au_id,a.au_fname,a.au_lname,A.address
