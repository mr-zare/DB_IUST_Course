use Northwind
--1
select ContactName from  dbo.Suppliers where ContactName LIKE 'S%'
--2 

select b.FirstName, b.LastName from dbo.Orders as a
inner join dbo.Employees as b on a.EmployeeID = b.EmployeeID
group by b.EmployeeID, b.FirstName, b.LastName having COUNT(*) > 3

--3
select LastName,(DATEDIFF(YY,BirthDate,GETDATE())-DATEDIFF(YY,HireDate,GETDATE())) from dbo.Employees where Title !='Sales Representative'

--4
select C.ContactName, C.Address from Orders as a
inner join [Order Details] as b on  b.OrderID=a.OrderID 
inner join Customers as C on a.CustomerID = a.CustomerID 
group by C.CustomerID, C.ContactName, C.Address
having SUM(b.Quantity*b.UnitPrice) > 6000

--5
select sum(b.Quantity) from Orders AS a inner join [Order Details] AS b on b.OrderID=a.OrderID  where ShipCountry='France' 

