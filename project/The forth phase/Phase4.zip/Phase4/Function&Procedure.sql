USE Secondhand_sales_system

--Functions
--1
IF OBJECT_ID (N'Get_Price') IS NOT NULL  
    DROP FUNCTION Get_Price;  
GO  
CREATE FUNCTION Get_Price(@Item_Id INT)  
RETURNS FLOAT(10) 
AS
BEGIN RETURN (SELECT Price 
              FROM item 
			  WHERE Id = @Item_Id)  
END 
GO
SELECT [dbo].Get_Price(2) Price

--2
IF OBJECT_ID (N'Item_Sold') IS NOT NULL  
    DROP FUNCTION Item_Sold;  
GO 
CREATE FUNCTION Item_Sold()
RETURNS @result TABLE
(
    Id INT,
    Category_Id INT,
    Guarantee INT,
    Price FLOAT(10),
    Name nVARCHAR(50),
    Quality nVARCHAR(50),
    Color nVARCHAR(15),
    Brand nVARCHAR(30),
    Description nVARCHAR(100),
    Duration_Of_Use nVARCHAR(30)
)
AS
BEGIN
    INSERT INTO @result
    SELECT i.Id, i.Category_Id, i.Guarantee, i.Price, i.Name, i.Quality, i.Color, i.Brand, i.Description, i.Duration_Of_Use
    FROM item AS i
    INNER JOIN advertisement AS a ON i.Id = a.Item_Id
    WHERE a.IsSold = 'True'
    RETURN
END
GO
SELECT *
FROM Item_Sold()

--Procedures
--1
IF OBJECT_ID (N'Get_count') IS NOT NULL  
    DROP PROCEDURE Get_count;  
GO  
CREATE PROCEDURE Get_count(@Title nVARCHAR(50))  
AS  
BEGIN
   SELECT c.Title, COUNT(*) Count
   FROM item AS i
   INNER JOIN category AS c ON c.Id = i.Category_Id
   WHERE c.Title = @Title
   GROUP BY(c.Title)
END
GO
EXEC Get_count 'console'

--2
IF OBJECT_ID (N'Different_cities') IS NOT NULL  
    DROP PROCEDURE Different_cities;  
GO  
CREATE PROCEDURE Different_cities  
AS  
BEGIN
   SELECT t.Seller_Id, ua1.City, t.Buyer_Id, ua2.City
   FROM _transaction AS t
   INNER JOIN _user AS u1 ON u1.Id = t.Seller_Id
   INNER JOIN user_adddress AS ua1 ON ua1.User_Id = u1.Id
   INNER JOIN _user AS u2 ON u2.Id = t.Buyer_Id 
   INNER JOIN user_adddress AS ua2 ON ua2.User_Id = u2.Id
   WHERE ua1.City != ua2.City
END
GO
EXEC Different_cities