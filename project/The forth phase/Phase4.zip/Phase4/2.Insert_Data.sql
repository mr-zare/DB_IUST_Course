USE Secondhand_sales_system

--User
insert into _user values(1,'ali','alaii',091912345,100);
insert into _user values(2,'reza','rezaii',091912346,200);
insert into _user values(3,'nima','nimaii',091912347,300);
insert into _user values(4,'goli','golaii',091912348,400);
insert into _user values(5,'iman','imani',091912349,500);
insert into _user values(6,'rima','rimaii',091912340,600);
insert into _user values(7,'erfan','arefi',091912341,700);

--User address
insert into user_adddress values(1,1234567890,'tehran','elmos');
insert into user_adddress values(2,4234567890,'yazd','safadasht');
insert into user_adddress values(3,6234567890,'tehran','farjam');

--Category
insert into category values(1,'sport',0.90,'post',24,18);
insert into category values(2,'car',0.80,'pishtaz',20,17);
insert into category values(3,'mobile',0.70,'post',18,15);
insert into category values(4,'console',0.76,'post',12,15);
insert into category values(5,'book',0.95,'post',22,14);
insert into category values(6,'laptop',0.60,'post',16,12);

--Item
insert into item values(1, 4, 18, 15.1, 'xbox', 'high','black','microsoft','have','18month')
insert into item values(2, 5, 1, 1.1, 'jenayAatvamokafat', 'daste2','brown','adineh','one of best book','1month')
insert into item values(3, 6, 15, 15.1, 'palystation','high', 'black','microsoft','have','2month')

--Item image
insert into item_image values(1, 1, null);
insert into item_image values(2, 3, null);
insert into item_image values(3, 2, null);

--Advertisement
insert into advertisement values(1, 1, 2, 0, 1 , null, '1905-06-24')
insert into advertisement values(2, 2, 1, 1, 2, null, '1902-09-28')
insert into advertisement values(3, 4, 3, 0, 44, null, '1902-08-28')
insert into advertisement values(4, 3, 2, 0, 55, null, '1910-09-20')
insert into advertisement values(5, 5, 3, 1, 50, null, '2000-09-28')

--Transaction
insert into _transaction values(1,1,2, '2012-2-2')
insert into _transaction values(6,2,3, '2012-5-2')
insert into _transaction values(7,3,1, '2012-4-2')