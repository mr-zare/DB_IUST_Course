USE Secondhand_sales_system

--Update table
--1
ALTER TABLE item
ADD Discount int CONSTRAINT Discount DEFAULT (0)
WITH VALUES
--2
ALTER TABLE user_adddress
ADD Country nVARCHAR (50) CONSTRAINT Country DEFAULT ('Iran')
WITH VALUES

--Update rows
--1
UPDATE _user
SET First_name = 'Zahra', Phone = 22984556
WHERE Id = 1;
--2
UPDATE item
SET Color = 'white'
WHERE Id = 3

--Delete from table
--1
DELETE FROM _user 
WHERE Id=3
--2
DELETE FROM advertisement 
WHERE Id=2