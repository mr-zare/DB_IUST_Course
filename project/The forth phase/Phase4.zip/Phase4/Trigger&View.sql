USE Secondhand_sales_system

--Trigger
--1
IF OBJECT_ID ('Delete_user') IS NOT NULL
   DROP TRIGGER Delete_user;
GO 
  
CREATE TRIGGER Delete_user ON _user   
INSTEAD OF DELETE
AS
BEGIN 

DELETE FROM _transaction 
WHERE Seller_Id IN (SELECT Id
                    FROM deleted)

DELETE FROM _transaction 
WHERE Buyer_Id IN (SELECT Id
                    FROM deleted)

DELETE FROM _user
WHERE Id IN (SELECT Id
             FROM deleted)
END

--2
DROP TRIGGER IF EXISTS Insert_item_image
GO
CREATE TRIGGER Insert_item_image ON item 
AFTER INSERT
AS
BEGIN
    DECLARE @Id INT
	SET @Id = (SELECT MAX(Id)
	           FROM item_image) + 1

	DECLARE @Item_Id INT
	SET @Item_Id = (SELECT Id
	                FROM Inserted)

	INSERT INTO item_image(Id, Item_Id, Image) VALUES (@Id, @Item_Id, NULL)
END 
--Example
--GO
--INSERT INTO item VALUES (100, 4, 20, 100, 'xbox', 'low','red','microsoft','have','3month')

--View
--1
DROP VIEW IF EXISTS [Tehran Users]
GO
CREATE VIEW [Tehran Users] AS
SELECT u.First_name, u.Last_name, u.Phone
FROM _user AS u
INNER JOIN user_adddress AS ua ON ua.User_Id = u.Id
WHERE City = 'tehran'
GO
SELECT *
FROM [Tehran Users]
--2
DROP VIEW IF EXISTS [Brand]
GO
CREATE VIEW [Brand] AS
SELECT Brand, COUNT(Brand) AS Count
FROM item 
GROUP BY Brand
GO
SELECT *
FROM [Brand]
