IF NOT EXISTS(SELECT * FROM sys.databases WHERE name = 'Secondhand_sales_system')
  BEGIN
    CREATE DATABASE [Secondhand_sales_system]


    END
    GO
       USE [Secondhand_sales_system]
    GO

--User
IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='_user')
BEGIN
CREATE TABLE _user (
Id INT PRIMARY KEY,
First_name nVARCHAR (50) NOT NULL,
Last_name nVARCHAR (50) NOT NULL,
Phone INT NOT NULL,
Wallet FLOAT NOT NULL,
CONSTRAINT Chk_Phone CHECK(LEN(Phone) = 8)
);
END

--User address
IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='user_adddress')
BEGIN
CREATE TABLE user_adddress (
User_Id INT UNIQUE REFERENCES _user(Id) ON DELETE CASCADE,
Postal_Code BIGINT PRIMARY KEY,
City nVARCHAR(50) NOT NULL,
Street nVARCHAR(50) NOT NULL,
CONSTRAINT Chk_Postal_Code CHECK(LEN(Postal_Code) = 10)
);
END

--Category
IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='category')
BEGIN
CREATE TABLE category (
Id INT PRIMARY KEY,
Title nVARCHAR(50) NOT NULL,
Satisfaction FLOAT,
How_to_send nVARCHAR(50),
Crash_Period INT,
Warranty INT
);
END

--Item
IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='item')
BEGIN
CREATE TABLE item (
Id INT PRIMARY KEY,
Category_Id INT REFERENCES category(Id) ON DELETE CASCADE,
Guarantee INT NOT NULL,
Price FLOAT(10) NOT NULL,
Name nVARCHAR(50) NOT NULL,
Quality nVARCHAR(50) NOT NULL,
Color nVARCHAR(15),
Brand nVARCHAR(30),
Description nVARCHAR(100),
Duration_Of_Use nVARCHAR(30)
);
END

--Item image
IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='item_image')
BEGIN
CREATE TABLE item_image (
Id INT PRIMARY KEY,
Item_Id INT NOT NULL,
Image IMAGE,
FOREIGN KEY (Item_Id) REFERENCES item (Id) ON DELETE CASCADE
);
END

--Advertisement
IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='advertisement')
BEGIN
   CREATE TABLE advertisement (
    Id INT PRIMARY KEY,
	User_Id INT REFERENCES _user(Id) ON DELETE CASCADE,
	Item_Id INT REFERENCES item(Id) ON DELETE CASCADE,
	IsSold BIT NOT NULL,
	Seen_Post INT NOT NULL,
	Description nVARCHAR (100),
	Date DATETIME NOT NULL,
	);
END

--Transaction
IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='_transaction')
BEGIN
   CREATE TABLE _transaction (
    Seller_Id INT NOT NULL,
    Item_Id INT NOT NULL,
    Buyer_Id INT NOT NULL,
	Date DATE NOT NULL,
	CHECK (Seller_Id != Buyer_Id),
	FOREIGN KEY (Seller_Id) REFERENCES _user (Id),
	FOREIGN KEY (Item_Id) REFERENCES item (Id) ON DELETE CASCADE,
	FOREIGN KEY (Buyer_Id) REFERENCES _user (Id)
	);
END