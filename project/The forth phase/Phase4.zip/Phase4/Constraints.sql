USE Secondhand_sales_system

--Add constraints
--1
ALTER TABLE _user
ADD CONSTRAINT Chk_Wallet CHECK (0 <= Wallet)
--2
ALTER TABLE category
ADD CONSTRAINT Chk_How_to_send CHECK (How_to_send = 'post' OR How_to_send = 'pishtaz' OR How_to_send = 'peyk')
--3
ALTER TABLE item
ADD CONSTRAINT Chk_Price CHECK (0 <= Price)

--Update constraints
--1
ALTER TABLE _user DROP CONSTRAINT Chk_Phone 
ALTER TABLE _user ADD CONSTRAINT Chk_Phone check (LEN(Phone) = 8 OR LEN(Phone) = 11)
--2
ALTER TABLE category DROP CONSTRAINT Chk_How_to_send 
ALTER TABLE category ADD CONSTRAINT Chk_How_to_send check (How_to_send = 'post' OR How_to_send = 'pishtaz')

--Delete constraints
--1
ALTER TABLE _user
DROP CONSTRAINT Chk_Phone;
--2
ALTER TABLE user_adddress
DROP CONSTRAINT Chk_Postal_Code;