USE Secondhand_sales_system

--1
DECLARE @Buyer_Id INT
SET @Buyer_Id = 1
SELECT i.*
FROM _transaction AS t
INNER JOIN item AS i ON t.Item_Id = i.Id
WHERE @Buyer_Id = t.Buyer_Id

--2
DECLARE @Seller_Id INT
SET @Seller_Id = 1
SELECT i.*
FROM _transaction AS t
INNER JOIN item AS i ON t.Item_Id = i.Id
WHERE @Seller_Id = t.Seller_Id

--3
DECLARE @city nVARCHAR (50)
SET @city = 'tehran'
SELECT *
FROM user_adddress AS ua
INNER JOIN _user AS u ON u.Id = ua.user_Id
WHERE city = @city

--4
DECLARE @MinPrice FLOAT(10)
DECLARE @MaxPrice FLOAT(10)
SET @MinPrice = 1
SET @MaxPrice = 10
SELECT Name, Price
FROM item
WHERE @MinPrice <= Price AND Price <= @MaxPrice

--5
DECLARE @Quality nvarchar(50)
SET @Quality = 'high'
SELECT *
FROM item
WHERE Quality = @Quality

--6
DECLARE @Title VARCHAR (50)
SET @Title = 'console'
SELECT i.*
FROM item AS i
INNER JOIN category AS c ON i.Category_Id = c.Id
WHERE c.Title = @Title

--7
DECLARE @user_id INT
SET @user_id = 1
SELECT * 
FROM advertisement 
WHERE User_id = @user_id

--8
DECLARE @MinDate DATE
DECLARE @MaxDate DATE
SET @MinDate = '2000-1-1'
SET @MaxDate = '2020-1-1'
SELECT *
FROM advertisement
WHERE DATEDIFF(DAY, @MinDate, Date) > 0 AND DATEDIFF(DAY, @MaxDate, Date) < 0

--9
SELECT * 
FROM advertisement
ORDER BY Seen_Post DESC

--10
DECLARE @Min_Date DATE
DECLARE @Max_Date DATE
SET @Min_Date = '2000-1-1'
SET @Max_Date = '2012-5-3'
SELECT COUNT(*) Total
FROM _transaction
WHERE DATEDIFF(DAY, @Min_Date, Date) > 0 AND DATEDIFF(DAY, @Max_Date, Date) < 0

--11
SELECT *
FROM item
WHERE Discount != 0

--12
DECLARE @MinGuarantee INT
DECLARE @MaxGuarantee INT
SET @MinGuarantee = 1
SET @MaxGuarantee = 10
SELECT *
FROM item
WHERE @MinGuarantee <= Guarantee AND Guarantee <= @MaxGuarantee

--13
SELECT i.* 
FROM _transaction AS t
INNER JOIN item AS i ON i.Id = t.Item_Id
INNER JOIN category AS c ON c.Id = i.Category_Id
WHERE i.Price <= 20 AND c.Title = 'console'

--14
SELECT *
FROM advertisement 
WHERE IsSold = 'False' AND Seen_Post > 40

--15
SELECT name, price
FROM item
WHERE Guarantee > 9 AND Duration_Of_Use IS NOT NULL

--16
SELECT Title
FROM category
WHERE Crash_Period < 24 AND Warranty IS NOT NULL

--17
SELECT *
FROM item_image
WHERE Image IS NOT NULL

--18
SELECT *
FROM _user
WHERE Wallet > 500

--19
SELECT * 
FROM category
WHERE Title = 'book' AND How_to_send = 'post'

--20
SELECT *
FROM item
WHERE Price < 100